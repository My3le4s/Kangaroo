print(15+15)
print(10*5)
print(12/2)
print(50-10)