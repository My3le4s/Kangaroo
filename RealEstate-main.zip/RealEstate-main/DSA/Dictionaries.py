#A dictionary has key and value pair
# You can modify a dictionary


friends ={"Mike":20, "Andrew":15, "Joe":30}
friends["Angela"] = 23
print(friends)