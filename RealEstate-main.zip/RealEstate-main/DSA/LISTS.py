#defined squared brackets
#you can add elements to your list
#A list has order
#remove items in a list



mylist =["Bob", "Rufus", "Ken", "Paul"]
mylist.append("Angela")
mylist.append("Wendy")
mylist.append("Ray")
print(mylist)