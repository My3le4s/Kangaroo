#order is not guaranteed
#defined with curly braces
#you cannot have duplicates in a set



myset = {"Ralph", "Greg","Joe", "Mary"}
myset.add("Cynthia")
myset.add("Simon")
myset.add("Martin")
print(myset)