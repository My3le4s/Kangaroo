#you cannot modiy a tuple
#a tuple will keep the order of items

mytuple =("Jane", "Liz", "Joe", "Chris")
print(mytuple)