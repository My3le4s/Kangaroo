#Integer
age = 20
#string
city ="Kisumu"
#floats
temperature =36.87
