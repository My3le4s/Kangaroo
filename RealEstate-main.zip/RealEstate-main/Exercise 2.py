age = int(input("Enter Age"))
s =age*12
print("You have lived", s,"months")