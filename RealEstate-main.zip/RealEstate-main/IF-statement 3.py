number =int(input("Enter any number between 0 to 98"))
if number == 0:
    print("Nyakua Bonus")
elif number == 1:
    print("Data Deals")
elif number == 2:
    print("Daily Bundles")
elif number == 3:
    print("Weekly Bundles")
elif number == 4:
    print("GO MONTHLY")
elif number == 5:
    print("No Expiry")
elif number == 6:
    print("Video Bundles")
elif number == 7:
    print("Okoa Data")
elif number == 8:
    print("Lipa MdogoMdogo")
elif number == 9:
    print("Data Plus NEW")
elif number == 10:
    print("Hot Minutes")
elif number == 11:
    print("Balance and Tips")
elif number == 12:
    print("Buy Newspaper")
elif number == 13:
    print("Sambaza Internet")
elif number == 14:
    print("Is My Sim 4G Enabled?")
elif number == 0:
    print("Back")
else :
    print("Invalid choice")