day = input("Enter day of the week")
if day == "Monday":
    print("True")
elif day == "Tuesday":
    print("True")
elif day == "Wednesday":
    print("True")
elif day == "Thursday":
    print("True")
elif day == "Friday":
    print("True")
elif day == "Saturday":
    print("True")
elif day == "Sunday":
    print("True")
else:
    print("False")
