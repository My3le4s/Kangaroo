age =int (input("Nuumber of months"))
ref = age /12
print("You have lived" ,ref,"years")