name ="kingstone"
age ="22"
country ="Bahamas"
parents ="Millie Cyrus"
print(f"My name is {name} and im {age} years")
print(f"i live in {country}")
print(f"My parents are{parents}")
