
number =int(input("Enter any number between 0 to 3"))
if number == 0:
    print("Welcome to Safaricom plus")
elif number == 1:
    print("Talk to customer care")
elif number == 2:
    print("Get Safaricom password")
elif number == 3:
    print("Back to home menu")
else :
    print("Invalid choice")