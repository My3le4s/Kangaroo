
num1 =int(input("Enter Any Number"))
num2 =int(input("Enter a second number"))
num3 =int(input("Enter the third number"))
print(num1)
print(num2)
print(num3)