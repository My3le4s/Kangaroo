def greetings():
    print("Habari zenu")

greetings()

def feedback():
        print("Mzuri sana")

feedback()

def wishes():
    print("Nice Day")

wishes()

def respond():
    print("Likewise")