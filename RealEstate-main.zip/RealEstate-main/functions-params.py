#functions with parameters

def addtwonums(num1, num2):
    results = num1 + num2
    print(results)
addtwonums(130, 20)




def multiplynums (num1, num2):
    result = num1 * num2
    print(result)
multiplynums(100, 50)