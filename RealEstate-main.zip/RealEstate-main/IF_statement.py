name =input("Enter your name")
if name == "Jay":
    print("its Jay")
else:
    print("Not Jay")
