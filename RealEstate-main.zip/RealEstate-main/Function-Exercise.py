def age_in_months():
    age = int(input("Please Enter Your Age:"))
    months = age * 12
    print("Your Age in Months", months)
age_in_months()