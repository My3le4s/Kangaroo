
num1 = 5
num2 = 5
print(num1 == num2)
num3 = 7
num4 = 3
print(num3 != num4)
num5 = 9
num6 = 3
print(num5 > num6)