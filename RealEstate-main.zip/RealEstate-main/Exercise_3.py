a =int(input("Enter the length of one side"))
b =int(input("Enter the width of one side"))

x = a * b
print("Your area code", x, "cm")